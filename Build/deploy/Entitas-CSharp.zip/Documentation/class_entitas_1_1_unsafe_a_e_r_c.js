var class_entitas_1_1_unsafe_a_e_r_c =
[
    [ "Release", "class_entitas_1_1_unsafe_a_e_r_c.html#a99c59b893812fe74add8518bc4496590", null ],
    [ "Retain", "class_entitas_1_1_unsafe_a_e_r_c.html#a76324a8dbfbddca80887a4caf303425e", null ],
    [ "retainCount", "class_entitas_1_1_unsafe_a_e_r_c.html#af3f26ffe832168de1330556afaa88b2f", null ]
];