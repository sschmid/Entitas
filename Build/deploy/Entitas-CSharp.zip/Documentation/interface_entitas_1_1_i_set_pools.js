var interface_entitas_1_1_i_set_pools =
[
    [ "SetPools", "interface_entitas_1_1_i_set_pools.html#a8e1009b2fe4f28b418ce0396ce0dc2b6", null ]
];