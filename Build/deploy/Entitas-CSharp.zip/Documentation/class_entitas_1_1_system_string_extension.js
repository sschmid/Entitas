var class_entitas_1_1_system_string_extension =
[
    [ "AddSystemSuffix", "class_entitas_1_1_system_string_extension.html#a4b338575614494b207836908c012c9fa", null ],
    [ "RemoveSystemSuffix", "class_entitas_1_1_system_string_extension.html#ae9c307769625aa136683958e8efd907c", null ]
];