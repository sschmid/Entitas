var class_entitas_1_1_context_info_exception =
[
    [ "ContextInfoException", "class_entitas_1_1_context_info_exception.html#a73a6b5399be167e7ffdf4fc4d63a6b82", null ]
];