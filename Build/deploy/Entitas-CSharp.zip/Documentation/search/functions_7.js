var searchData=
[
  ['implementsinterface_3c_20t_20_3e',['ImplementsInterface&lt; T &gt;',['../class_entitas_1_1_type_extension.html#ad378941eb1727d00fd7774428dbd5883',1,'Entitas::TypeExtension']]],
  ['initialize',['Initialize',['../class_entitas_1_1_systems.html#a33b35b3cdbdb16c347086a4ce4a23495',1,'Entitas::Systems']]]
];
