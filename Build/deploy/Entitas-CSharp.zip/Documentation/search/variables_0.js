var searchData=
[
  ['owners',['owners',['../class_entitas_1_1_entity.html#ad0aefa732e6c3cb99be6530b26024b63',1,'Entitas::Entity']]]
];
