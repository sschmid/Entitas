var indexSectionsWithContent =
{
  0: "acdefghimoprstu",
  1: "acegimprstu",
  2: "e",
  3: "acdefghirstu",
  4: "acimrt",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "properties",
  5: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Properties",
  5: "Events"
};

