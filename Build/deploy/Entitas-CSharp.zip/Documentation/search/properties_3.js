var searchData=
[
  ['matcher',['matcher',['../class_entitas_1_1_group.html#ae48b92ee4d75ca6ec41d1e1187e3b1a2',1,'Entitas::Group']]]
];
