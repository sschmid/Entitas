var searchData=
[
  ['deactivate',['Deactivate',['../class_entitas_1_1_collector.html#a0576860c5596513cdc0b8ea911b49e87',1,'Entitas.Collector.Deactivate()'],['../class_entitas_1_1_reactive_system.html#a84b1f875f0504ab8611f348c5d762e29',1,'Entitas.ReactiveSystem.Deactivate()']]],
  ['deactivatereactivesystems',['DeactivateReactiveSystems',['../class_entitas_1_1_systems.html#aa99602f321bc4feb11e11e586493f805',1,'Entitas::Systems']]]
];
