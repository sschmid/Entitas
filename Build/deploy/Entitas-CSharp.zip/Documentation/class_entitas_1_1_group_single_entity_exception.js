var class_entitas_1_1_group_single_entity_exception =
[
    [ "GroupSingleEntityException", "class_entitas_1_1_group_single_entity_exception.html#a5ae395389ff4e93ef57d3c5dc95fb1f0", null ]
];