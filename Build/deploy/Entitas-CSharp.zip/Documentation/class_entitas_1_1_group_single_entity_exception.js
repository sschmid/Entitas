var class_entitas_1_1_group_single_entity_exception =
[
    [ "GroupSingleEntityException", "class_entitas_1_1_group_single_entity_exception.html#ae39016dff6dfe26d31d8d9c0e3ccb615", null ]
];