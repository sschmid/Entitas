var class_entitas_1_1_code_generator_1_1_custom_component_name_attribute =
[
    [ "CustomComponentNameAttribute", "class_entitas_1_1_code_generator_1_1_custom_component_name_attribute.html#aa70721231e64d6cfb99bdfc832b0c3e7", null ],
    [ "componentNames", "class_entitas_1_1_code_generator_1_1_custom_component_name_attribute.html#ae88e9be8bb34b72db542cfb0bc4efe6d", null ]
];