var dir_1efbe5ff38eb8fbf4811d1cf1d3b68b8 =
[
    [ "CollectionExtension.cs", "_collection_extension_8cs_source.html", null ],
    [ "ContextExtension.cs", "_context_extension_8cs_source.html", null ],
    [ "EntityExtension.cs", "_entity_extension_8cs_source.html", null ],
    [ "GroupExtension.cs", "_group_extension_8cs_source.html", null ],
    [ "TypeExtension.cs", "_type_extension_8cs_source.html", null ]
];