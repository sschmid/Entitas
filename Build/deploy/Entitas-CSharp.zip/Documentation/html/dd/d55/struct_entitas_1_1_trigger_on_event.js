var struct_entitas_1_1_trigger_on_event =
[
    [ "TriggerOnEvent", "dd/d55/struct_entitas_1_1_trigger_on_event.html#a46151d8f477796825cc5886d0687e1fc", null ],
    [ "eventType", "dd/d55/struct_entitas_1_1_trigger_on_event.html#a1dcc20fc9a25405c37846986b13c14d2", null ],
    [ "trigger", "dd/d55/struct_entitas_1_1_trigger_on_event.html#ad24d56370f5f1b67567be4c0111664f5", null ]
];