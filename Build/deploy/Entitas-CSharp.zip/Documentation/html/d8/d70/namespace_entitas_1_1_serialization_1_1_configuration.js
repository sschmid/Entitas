var namespace_entitas_1_1_serialization_1_1_configuration =
[
    [ "CodeGeneratorConfig", "dc/dfd/class_entitas_1_1_serialization_1_1_configuration_1_1_code_generator_config.html", "dc/dfd/class_entitas_1_1_serialization_1_1_configuration_1_1_code_generator_config" ],
    [ "EntitasPreferencesConfig", "d9/db5/class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences_config.html", "d9/db5/class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences_config" ],
    [ "Properties", "d0/d40/class_entitas_1_1_serialization_1_1_configuration_1_1_properties.html", "d0/d40/class_entitas_1_1_serialization_1_1_configuration_1_1_properties" ]
];