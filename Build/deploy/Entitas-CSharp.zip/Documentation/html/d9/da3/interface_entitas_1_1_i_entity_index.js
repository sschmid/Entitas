var interface_entitas_1_1_i_entity_index =
[
    [ "Activate", "d9/da3/interface_entitas_1_1_i_entity_index.html#a8b7e3929f65a5a2d64d33a05ebabf2b8", null ],
    [ "Deactivate", "d9/da3/interface_entitas_1_1_i_entity_index.html#a6f78f04118f83f796e830b2fb7fd4642", null ]
];