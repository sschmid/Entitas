var searchData=
[
  ['poolmetadata',['poolMetaData',['../d7/d9a/class_entitas_1_1_entity.html#a242ca061f78a188f84b730d2ccd4ab32',1,'Entitas::Entity']]]
];
