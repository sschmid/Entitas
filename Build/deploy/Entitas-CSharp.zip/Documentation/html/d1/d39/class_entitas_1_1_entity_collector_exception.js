var class_entitas_1_1_entity_collector_exception =
[
    [ "EntityCollectorException", "d1/d39/class_entitas_1_1_entity_collector_exception.html#a236e349e630f9c68ecc2c920a5220e37", null ]
];