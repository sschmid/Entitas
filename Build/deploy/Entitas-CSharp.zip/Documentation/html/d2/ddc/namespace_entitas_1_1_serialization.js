var namespace_entitas_1_1_serialization =
[
    [ "Blueprints", "db/d57/namespace_entitas_1_1_serialization_1_1_blueprints.html", "db/d57/namespace_entitas_1_1_serialization_1_1_blueprints" ],
    [ "Configuration", "d8/d70/namespace_entitas_1_1_serialization_1_1_configuration.html", "d8/d70/namespace_entitas_1_1_serialization_1_1_configuration" ],
    [ "AttributeInfo", "d3/d76/class_entitas_1_1_serialization_1_1_attribute_info.html", "d3/d76/class_entitas_1_1_serialization_1_1_attribute_info" ],
    [ "PublicMemberInfo", "d4/dd9/class_entitas_1_1_serialization_1_1_public_member_info.html", "d4/dd9/class_entitas_1_1_serialization_1_1_public_member_info" ]
];