var class_entitas_1_1_group_extension =
[
    [ "CreateCollector< TEntity >", "class_entitas_1_1_group_extension.html#a7479a1a33807ecd1310191244ec24bdf", null ]
];