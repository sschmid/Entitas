var class_entitas_1_1_group_extension =
[
    [ "CreateCollector", "class_entitas_1_1_group_extension.html#a45528de8d04575b70b41634249cd9e85", null ]
];