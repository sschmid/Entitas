var class_entitas_1_1_contexts =
[
    [ "CreateContext", "class_entitas_1_1_contexts.html#a04036b8b724a53ee315a0bfe8c27ed57", null ],
    [ "sharedInstance", "class_entitas_1_1_contexts.html#aaf78c120643ec6bb6950dc81ab459f50", null ]
];