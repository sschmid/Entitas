var class_entitas_1_1_i_matcher_extension =
[
    [ "OnEntityAdded", "class_entitas_1_1_i_matcher_extension.html#a13ee57ed2b36a08e530f97bcc7b61abd", null ],
    [ "OnEntityAddedOrRemoved", "class_entitas_1_1_i_matcher_extension.html#aae82da31a25463240cf11de1cd55c6b1", null ],
    [ "OnEntityRemoved", "class_entitas_1_1_i_matcher_extension.html#aca64868b160502b29dbb2fa3d13f4a3b", null ]
];