var class_entitas_1_1_serialization_1_1_attribute_info =
[
    [ "AttributeInfo", "class_entitas_1_1_serialization_1_1_attribute_info.html#a6ed6428c771c0e3d6ec17b5b646b35ac", null ],
    [ "attribute", "class_entitas_1_1_serialization_1_1_attribute_info.html#a30cf7cdc8acfe0348bca59119140fbb1", null ],
    [ "memberInfos", "class_entitas_1_1_serialization_1_1_attribute_info.html#a72583e499f4ba61c171fc8655622446f", null ]
];