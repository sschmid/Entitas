var namespace_entitas_1_1_serialization_1_1_configuration =
[
    [ "CodeGeneratorConfig", "class_entitas_1_1_serialization_1_1_configuration_1_1_code_generator_config.html", "class_entitas_1_1_serialization_1_1_configuration_1_1_code_generator_config" ],
    [ "EntitasPreferences", "class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences.html", "class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences" ],
    [ "EntitasPreferencesConfig", "class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences_config.html", "class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences_config" ],
    [ "Properties", "class_entitas_1_1_serialization_1_1_configuration_1_1_properties.html", "class_entitas_1_1_serialization_1_1_configuration_1_1_properties" ]
];