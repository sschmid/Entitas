var dir_c99a51b1778bc6979b97974e60b03bb4 =
[
    [ "ContextDoesNotContainEntityException.cs", "_context_does_not_contain_entity_exception_8cs_source.html", null ],
    [ "ContextEntityIndexDoesAlreadyExistException.cs", "_context_entity_index_does_already_exist_exception_8cs_source.html", null ],
    [ "ContextEntityIndexDoesNotExistException.cs", "_context_entity_index_does_not_exist_exception_8cs_source.html", null ],
    [ "ContextInfoException.cs", "_context_info_exception_8cs_source.html", null ],
    [ "ContextStillHasRetainedEntitiesException.cs", "_context_still_has_retained_entities_exception_8cs_source.html", null ],
    [ "EntityIsNotDestroyedException.cs", "_entity_is_not_destroyed_exception_8cs_source.html", null ]
];