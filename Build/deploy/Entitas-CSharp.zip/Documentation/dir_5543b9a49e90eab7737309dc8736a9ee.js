var dir_5543b9a49e90eab7737309dc8736a9ee =
[
    [ "Exceptions", "dir_9e7c286d682d7af5dbfd2e28444afa0c.html", "dir_9e7c286d682d7af5dbfd2e28444afa0c" ],
    [ "Entity.cs", "_entity_8cs_source.html", null ],
    [ "EntityEqualityComparer.cs", "_entity_equality_comparer_8cs_source.html", null ]
];