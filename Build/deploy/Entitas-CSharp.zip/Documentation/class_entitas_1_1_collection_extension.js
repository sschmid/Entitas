var class_entitas_1_1_collection_extension =
[
    [ "SingleEntity", "class_entitas_1_1_collection_extension.html#a4d60c49a5d86ec4b6d07104e437487aa", null ]
];