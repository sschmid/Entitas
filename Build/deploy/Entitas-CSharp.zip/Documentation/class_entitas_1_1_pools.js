var class_entitas_1_1_pools =
[
    [ "CreatePool", "class_entitas_1_1_pools.html#a096096cf21a8d071f28861e265f4ae40", null ],
    [ "sharedInstance", "class_entitas_1_1_pools.html#a8cda1e580ad8d524ac74c94aa38967b1", null ]
];