var class_entitas_1_1_entitas_preferences =
[
    [ "LoadConfig", "class_entitas_1_1_entitas_preferences.html#a4f8ac094ffc94633a722134dfcbb30ac", null ],
    [ "SaveConfig", "class_entitas_1_1_entitas_preferences.html#a6b7c4dcf61005beb8dfc1d04874d89b4", null ],
    [ "CONFIG_PATH", "class_entitas_1_1_entitas_preferences.html#ac5f6e0e8621308f4079cec33691dba78", null ]
];