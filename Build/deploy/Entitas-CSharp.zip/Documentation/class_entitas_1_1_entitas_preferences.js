var class_entitas_1_1_entitas_preferences =
[
    [ "LoadConfig", "class_entitas_1_1_entitas_preferences.html#a4f8ac094ffc94633a722134dfcbb30ac", null ],
    [ "SaveConfig", "class_entitas_1_1_entitas_preferences.html#a6b7c4dcf61005beb8dfc1d04874d89b4", null ],
    [ "CONFIG_PATH", "class_entitas_1_1_entitas_preferences.html#aa818a93d2dff07e2ca45e6844b3bf7f6", null ]
];