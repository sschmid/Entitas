var interface_entitas_1_1_i_entity_index =
[
    [ "Activate", "interface_entitas_1_1_i_entity_index.html#a8b7e3929f65a5a2d64d33a05ebabf2b8", null ],
    [ "Deactivate", "interface_entitas_1_1_i_entity_index.html#a6f78f04118f83f796e830b2fb7fd4642", null ],
    [ "name", "interface_entitas_1_1_i_entity_index.html#ad1a27281c1cf2cc574968f706684efa6", null ]
];