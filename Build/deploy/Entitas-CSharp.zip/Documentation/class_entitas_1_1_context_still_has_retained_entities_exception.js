var class_entitas_1_1_context_still_has_retained_entities_exception =
[
    [ "ContextStillHasRetainedEntitiesException", "class_entitas_1_1_context_still_has_retained_entities_exception.html#a8efc0a0806506e00a66abcb3097480b0", null ]
];