var class_entitas_1_1_context_still_has_retained_entities_exception =
[
    [ "ContextStillHasRetainedEntitiesException", "class_entitas_1_1_context_still_has_retained_entities_exception.html#a10b73ac18af578f8f09cb3bda5ca764c", null ]
];