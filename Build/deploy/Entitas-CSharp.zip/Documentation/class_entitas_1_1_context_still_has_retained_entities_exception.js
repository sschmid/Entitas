var class_entitas_1_1_context_still_has_retained_entities_exception =
[
    [ "ContextStillHasRetainedEntitiesException", "class_entitas_1_1_context_still_has_retained_entities_exception.html#a587217a3d7b0ff7df8961b78c41c0a77", null ]
];