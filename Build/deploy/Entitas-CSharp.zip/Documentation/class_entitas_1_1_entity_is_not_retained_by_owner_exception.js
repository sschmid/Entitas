var class_entitas_1_1_entity_is_not_retained_by_owner_exception =
[
    [ "EntityIsNotRetainedByOwnerException", "class_entitas_1_1_entity_is_not_retained_by_owner_exception.html#a7af0c82f7977d01c1c2063338cd33fd5", null ]
];