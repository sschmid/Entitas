var namespaces =
[
    [ "Entitas", "namespace_entitas.html", "namespace_entitas" ]
];