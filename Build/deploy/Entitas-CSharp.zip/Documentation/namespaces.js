var namespaces =
[
    [ "Entitas", "namespace_entitas.html", null ]
];