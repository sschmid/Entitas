namespace Entitas {

    public interface IEntityIndex {

        void Activate();
        void Deactivate();
    }
}
