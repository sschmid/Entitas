namespace Entitas {

    public enum GroupEvent : byte {
        Added,
        Removed,
        AddedOrRemoved
    }
}
