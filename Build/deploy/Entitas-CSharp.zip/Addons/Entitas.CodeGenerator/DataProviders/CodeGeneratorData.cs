﻿using System.Collections.Generic;

namespace Entitas.CodeGenerator {

    public class CodeGeneratorData : Dictionary<string, object> {
    }
}
