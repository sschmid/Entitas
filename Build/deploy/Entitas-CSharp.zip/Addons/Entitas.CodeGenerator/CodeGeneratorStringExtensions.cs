namespace Entitas.CodeGenerator {

    public static class CodeGeneratorStringExtensions {

        public static string UppercaseFirst(this string str) {
            return char.ToUpper(str[0]) + str.Substring(1);
        }

        public static string LowercaseFirst(this string str) {
            return char.ToLower(str[0]) + str.Substring(1);
        }

        public static string ToUnixLineEndings(this string str) {
            return str.Replace("\r\n", "\n").Replace("\r", "\n");
        }
    }
}
