namespace Entitas.CodeGenerator.Api {

    public enum EntityIndexType {
        EntityIndex,
        PrimaryEntityIndex
    }
}
