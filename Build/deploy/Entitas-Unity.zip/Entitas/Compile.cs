namespace Entitas.CodeGeneration.Unity.Editor {

    class Compile {}
}
