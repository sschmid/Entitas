﻿namespace Entitas.CodeGenerator {

    public class ComponentData : CodeGeneratorData {
    }
}
