﻿namespace Entitas.CodeGenerator {

    public class EntityIndexData : CodeGeneratorData {
    }
}
