﻿namespace Entitas.CodeGenerator {

    public class ContextData : CodeGeneratorData {
    }
}
