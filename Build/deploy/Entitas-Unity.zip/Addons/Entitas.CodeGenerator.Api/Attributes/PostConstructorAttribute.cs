﻿using System;

namespace Entitas.CodeGenerator.Api {

    [AttributeUsage(AttributeTargets.Method)]
    public class PostConstructorAttribute : Attribute {
    }
}
