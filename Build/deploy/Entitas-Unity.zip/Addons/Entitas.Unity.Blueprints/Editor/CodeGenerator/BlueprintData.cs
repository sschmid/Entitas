﻿using Entitas.CodeGenerator;

namespace Entitas.Unity.Blueprints {

    public class BlueprintData : CodeGeneratorData {
    }
}
