﻿using System;

namespace Entitas.Unity.VisualDebugging {

    [AttributeUsage(AttributeTargets.Class)]
    public class DontDrawComponentAttribute : Attribute {
    }
}
