var class_entitas_1_1_serialization_1_1_blueprints_1_1_serializable_member =
[
    [ "SerializableMember", "class_entitas_1_1_serialization_1_1_blueprints_1_1_serializable_member.html#acb006aa7535cf95796a376b5b1f70f5d", null ],
    [ "SerializableMember", "class_entitas_1_1_serialization_1_1_blueprints_1_1_serializable_member.html#a41b55e9936441de9d3852b04c5ba0cd9", null ],
    [ "name", "class_entitas_1_1_serialization_1_1_blueprints_1_1_serializable_member.html#acd703213d42154ab180048ddda40cb70", null ],
    [ "value", "class_entitas_1_1_serialization_1_1_blueprints_1_1_serializable_member.html#aa12f26cbe46008ddd3c1a73da906d515", null ]
];