var class_entitas_1_1_collector_exception =
[
    [ "CollectorException", "class_entitas_1_1_collector_exception.html#afef700f4b1526d87be0ec0ab90c10c06", null ]
];