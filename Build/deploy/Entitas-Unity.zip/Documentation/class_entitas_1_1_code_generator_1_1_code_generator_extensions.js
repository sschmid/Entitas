var class_entitas_1_1_code_generator_1_1_code_generator_extensions =
[
    [ "ComponentLookupTags", "class_entitas_1_1_code_generator_1_1_code_generator_extensions.html#a11d2aa9c4f7df8e1cdf8dfc5949ba16d", null ],
    [ "ContextPrefix", "class_entitas_1_1_code_generator_1_1_code_generator_extensions.html#a2eeadc6fc46876b09b616168d881fa39", null ],
    [ "IsDefaultContextName", "class_entitas_1_1_code_generator_1_1_code_generator_extensions.html#ac134e2d2a6ec5193611f864fc498e085", null ],
    [ "LowercaseFirst", "class_entitas_1_1_code_generator_1_1_code_generator_extensions.html#a5e7f1f7cfa73e01e6172b7d90a20714e", null ],
    [ "ToUnixLineEndings", "class_entitas_1_1_code_generator_1_1_code_generator_extensions.html#a6eaae3895528737aceec339904a1a7bc", null ],
    [ "UppercaseFirst", "class_entitas_1_1_code_generator_1_1_code_generator_extensions.html#affc71b9b09c3aa904de823bd3c66ed4f", null ]
];