var class_entitas_1_1_code_generator_1_1_custom_prefix_attribute =
[
    [ "CustomPrefixAttribute", "class_entitas_1_1_code_generator_1_1_custom_prefix_attribute.html#a3da6843af14c3f1fbe3c492bd64c4411", null ],
    [ "prefix", "class_entitas_1_1_code_generator_1_1_custom_prefix_attribute.html#a72766aaf6b3518278a9e10be3b0dc07d", null ]
];