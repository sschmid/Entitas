var class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences =
[
    [ "LoadConfig", "class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences.html#a9d07e536e6a0c5715f3acb3435d5dac6", null ],
    [ "SaveConfig", "class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences.html#a785331629d261a1763a3496ebc8e8210", null ],
    [ "CONFIG_PATH", "class_entitas_1_1_serialization_1_1_configuration_1_1_entitas_preferences.html#a7f4374f023f653ea5d164eae0d8d466b", null ]
];