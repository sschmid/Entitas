var class_entitas_1_1_code_generator_1_1_context_attribute =
[
    [ "ContextAttribute", "class_entitas_1_1_code_generator_1_1_context_attribute.html#ab253978d5029b2c57516cd9f166ac8aa", null ],
    [ "contextName", "class_entitas_1_1_code_generator_1_1_context_attribute.html#a9c9625014a8d9d9d4eb6ac0c17b6c01e", null ]
];