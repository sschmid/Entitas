var class_entitas_1_1_attribute_info =
[
    [ "AttributeInfo", "class_entitas_1_1_attribute_info.html#ab56b5408a55be39331c6a91113578754", null ],
    [ "attribute", "class_entitas_1_1_attribute_info.html#af01688aaa77e688eb48da907dc32255b", null ],
    [ "memberInfos", "class_entitas_1_1_attribute_info.html#a7e43339e847ec94cb5a63d5fa2c088de", null ]
];