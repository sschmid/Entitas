var interface_entitas_1_1_code_generator_1_1_i_code_generator_data_provider =
[
    [ "blueprintNames", "interface_entitas_1_1_code_generator_1_1_i_code_generator_data_provider.html#a80609195ccbe2479664680a15cffdf99", null ],
    [ "componentInfos", "interface_entitas_1_1_code_generator_1_1_i_code_generator_data_provider.html#a3dd2eb191531a46cb35cf18c2dde7526", null ],
    [ "contextNames", "interface_entitas_1_1_code_generator_1_1_i_code_generator_data_provider.html#a9e99d509f6a597379d38610bb54fdae4", null ]
];