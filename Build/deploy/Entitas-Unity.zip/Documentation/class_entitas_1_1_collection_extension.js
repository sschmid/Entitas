var class_entitas_1_1_collection_extension =
[
    [ "SingleEntity", "class_entitas_1_1_collection_extension.html#a57b0cefb881fa38432706a4fc91a609e", null ],
    [ "SingleEntity< TEntity >", "class_entitas_1_1_collection_extension.html#a8a1d04bbc143d69a962b99d99bde3b01", null ]
];