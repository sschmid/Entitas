var interface_entitas_1_1_i_matcher =
[
    [ "Matches", "interface_entitas_1_1_i_matcher.html#a4c837e3fb870be527a045246477e64fc", null ],
    [ "indices", "interface_entitas_1_1_i_matcher.html#a7479d79274d3dea4bc5b8339879c63bc", null ]
];