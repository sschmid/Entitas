var class_entitas_1_1_entitas_exception =
[
    [ "EntitasException", "class_entitas_1_1_entitas_exception.html#ac74de9af77681f86a70155fda1d76d5d", null ]
];