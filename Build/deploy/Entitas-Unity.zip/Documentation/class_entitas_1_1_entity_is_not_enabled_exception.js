var class_entitas_1_1_entity_is_not_enabled_exception =
[
    [ "EntityIsNotEnabledException", "class_entitas_1_1_entity_is_not_enabled_exception.html#a597c886c46e93e0806b883c28ac9b54b", null ]
];