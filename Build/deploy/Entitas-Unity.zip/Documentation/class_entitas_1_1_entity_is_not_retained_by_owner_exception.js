var class_entitas_1_1_entity_is_not_retained_by_owner_exception =
[
    [ "EntityIsNotRetainedByOwnerException", "class_entitas_1_1_entity_is_not_retained_by_owner_exception.html#adb122753a604b230e2aa4209426f8144", null ]
];