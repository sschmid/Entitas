var class_entitas_1_1_context_extension =
[
    [ "CloneEntity", "class_entitas_1_1_context_extension.html#a2fa6720418e1a1f6a3d6f1e18e2d02a7", null ],
    [ "CreateCollector", "class_entitas_1_1_context_extension.html#ac3a7f13281cff6cf9792c33bd7776d2e", null ],
    [ "GetEntities", "class_entitas_1_1_context_extension.html#a4d8b507b1bfa163af31a68bacb8acf6f", null ]
];