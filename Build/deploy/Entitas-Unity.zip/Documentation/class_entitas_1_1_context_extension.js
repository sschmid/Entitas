var class_entitas_1_1_context_extension =
[
    [ "CloneEntity< TEntity >", "class_entitas_1_1_context_extension.html#acfebf72578085b093aea4321d371cd32", null ],
    [ "CreateCollector< TEntity >", "class_entitas_1_1_context_extension.html#ab73231c56bb0be5ea9e80be5a783a1f3", null ],
    [ "GetEntities< TEntity >", "class_entitas_1_1_context_extension.html#ab25d48b0938653d8abbe661f46b6b971", null ]
];