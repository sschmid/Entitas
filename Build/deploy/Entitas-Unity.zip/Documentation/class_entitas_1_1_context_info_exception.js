var class_entitas_1_1_context_info_exception =
[
    [ "ContextInfoException", "class_entitas_1_1_context_info_exception.html#a2e774671c949ebcab0f7b8baa434c2b4", null ]
];