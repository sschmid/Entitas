var class_entitas_1_1_context_does_not_contain_entity_exception =
[
    [ "ContextDoesNotContainEntityException", "class_entitas_1_1_context_does_not_contain_entity_exception.html#aed49e39403312c8ba29e3a5f57e0327f", null ]
];