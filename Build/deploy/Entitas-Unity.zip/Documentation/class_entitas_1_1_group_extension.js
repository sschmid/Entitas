var class_entitas_1_1_group_extension =
[
    [ "CreateCollector< TEntity >", "class_entitas_1_1_group_extension.html#ae57c53eca0540b768310d0661b37b26e", null ]
];