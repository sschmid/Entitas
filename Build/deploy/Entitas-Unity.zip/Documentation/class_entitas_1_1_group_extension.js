var class_entitas_1_1_group_extension =
[
    [ "CreateCollector", "class_entitas_1_1_group_extension.html#aa61bb1fe15037125c731fee8bee4e0b0", null ]
];