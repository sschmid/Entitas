var dir_b5c9b5af985ba2a75445e7f80a31bb49 =
[
    [ "EntitasPreferences.cs", "_entitas_preferences_8cs_source.html", null ],
    [ "EntitasPreferencesConfig.cs", "_entitas_preferences_config_8cs_source.html", null ],
    [ "Properties.cs", "_properties_8cs_source.html", null ]
];