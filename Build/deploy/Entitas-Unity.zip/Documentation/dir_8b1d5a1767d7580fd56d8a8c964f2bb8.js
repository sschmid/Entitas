var dir_8b1d5a1767d7580fd56d8a8c964f2bb8 =
[
    [ "CodeGeneratorConfig.cs", "_code_generator_config_8cs_source.html", null ],
    [ "EntitasPreferences.cs", "_entitas_preferences_8cs_source.html", null ],
    [ "EntitasPreferencesConfig.cs", "_entitas_preferences_config_8cs_source.html", null ],
    [ "Properties.cs", "_properties_8cs_source.html", null ]
];