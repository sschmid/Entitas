var class_entitas_1_1_entity_index_exception =
[
    [ "EntityIndexException", "d1/d3c/class_entitas_1_1_entity_index_exception.html#a3ab5e37f2a8ec2e43f2049a91e66e7d5", null ]
];