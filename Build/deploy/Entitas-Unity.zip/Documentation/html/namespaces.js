var namespaces =
[
    [ "Entitas", "da/d57/namespace_entitas.html", "da/d57/namespace_entitas" ]
];