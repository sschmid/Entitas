var class_entitas_1_1_pool_does_not_contain_entity_exception =
[
    [ "PoolDoesNotContainEntityException", "d8/dd8/class_entitas_1_1_pool_does_not_contain_entity_exception.html#afefb29e55b6aa7c31332fb09cde2908d", null ]
];