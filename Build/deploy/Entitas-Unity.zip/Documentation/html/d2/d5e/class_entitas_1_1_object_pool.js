var class_entitas_1_1_object_pool =
[
    [ "ObjectPool", "d2/d5e/class_entitas_1_1_object_pool.html#a43a3b12b025186791cebe0b888e196fd", null ],
    [ "Get", "d2/d5e/class_entitas_1_1_object_pool.html#a262f6ad54674b6034c3155de6b7c5680", null ],
    [ "Push", "d2/d5e/class_entitas_1_1_object_pool.html#a5fce658a87afda3a52b91225957437ef", null ]
];