var searchData=
[
  ['objectcache',['ObjectCache',['../dc/d9b/class_entitas_1_1_object_cache.html',1,'Entitas']]],
  ['objectpool',['ObjectPool',['../d2/d5e/class_entitas_1_1_object_pool.html',1,'Entitas']]],
  ['oldpoolsgenerator',['OldPoolsGenerator',['../dd/d5a/class_entitas_1_1_code_generator_1_1_old_pools_generator.html',1,'Entitas::CodeGenerator']]]
];
