var searchData=
[
  ['pool',['Pool',['../d4/d91/class_entitas_1_1_pool.html#a7d2073fc0f12c1d2310eb68f2ab31541',1,'Entitas.Pool.Pool(int totalComponents)'],['../d4/d91/class_entitas_1_1_pool.html#a39392bb5c9ab551a7a2e6f47cabd0ed4',1,'Entitas.Pool.Pool(int totalComponents, int startCreationIndex, PoolMetaData metaData)']]]
];
