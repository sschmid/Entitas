var searchData=
[
  ['matcher',['matcher',['../db/d17/class_entitas_1_1_group.html#a17e57de15fefc676ba6f2b78f0d69c43',1,'Entitas::Group']]],
  ['metadata',['metaData',['../d4/d91/class_entitas_1_1_pool.html#ad6d9399a123dd1f355474e032f9bacb5',1,'Entitas::Pool']]]
];
