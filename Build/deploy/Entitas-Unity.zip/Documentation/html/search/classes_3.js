var searchData=
[
  ['dontgenerateattribute',['DontGenerateAttribute',['../d8/d91/class_entitas_1_1_code_generator_1_1_dont_generate_attribute.html',1,'Entitas::CodeGenerator']]]
];
