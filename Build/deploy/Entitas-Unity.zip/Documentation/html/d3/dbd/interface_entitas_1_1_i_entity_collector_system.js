var interface_entitas_1_1_i_entity_collector_system =
[
    [ "entityCollector", "d3/dbd/interface_entitas_1_1_i_entity_collector_system.html#a2784b7a895f777fec7473de5ae57c95e", null ]
];