var class_entitas_1_1_code_generator_1_1_pool_attribute =
[
    [ "PoolAttribute", "de/d23/class_entitas_1_1_code_generator_1_1_pool_attribute.html#a80c72af565b7b0faca58a589bb731cd4", null ],
    [ "poolName", "de/d23/class_entitas_1_1_code_generator_1_1_pool_attribute.html#a5e26c28f522b3f51ba123112d1688a19", null ]
];