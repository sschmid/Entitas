var class_entitas_1_1_object_cache =
[
    [ "ObjectCache", "dc/d9b/class_entitas_1_1_object_cache.html#a7d7bf790828704027d850490c035c446", null ],
    [ "Get< T >", "dc/d9b/class_entitas_1_1_object_cache.html#a8317466bca3e1f9ddde2d1bec819c25f", null ],
    [ "GetObjectPool< T >", "dc/d9b/class_entitas_1_1_object_cache.html#a712da1aa9942b998300851f0d4fb2190", null ],
    [ "Push< T >", "dc/d9b/class_entitas_1_1_object_cache.html#a5fc780f257983b82dd4b5d3973453217", null ],
    [ "RegisterCustomObjectPool< T >", "dc/d9b/class_entitas_1_1_object_cache.html#a13d8b7667f6067a5e3607c5b253ea659", null ],
    [ "Reset", "dc/d9b/class_entitas_1_1_object_cache.html#aa92a972966144b7612e36553a5f8e0e9", null ]
];