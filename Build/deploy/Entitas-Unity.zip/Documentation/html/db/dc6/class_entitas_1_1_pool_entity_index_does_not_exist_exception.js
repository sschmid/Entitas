var class_entitas_1_1_pool_entity_index_does_not_exist_exception =
[
    [ "PoolEntityIndexDoesNotExistException", "db/dc6/class_entitas_1_1_pool_entity_index_does_not_exist_exception.html#a29d6d312397e64d6585134189dced7f1", null ]
];