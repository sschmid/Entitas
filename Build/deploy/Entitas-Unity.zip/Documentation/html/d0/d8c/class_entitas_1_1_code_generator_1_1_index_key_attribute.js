var class_entitas_1_1_code_generator_1_1_index_key_attribute =
[
    [ "IndexKeyAttribute", "d0/d8c/class_entitas_1_1_code_generator_1_1_index_key_attribute.html#a2f4910d00ac3956c061394b31ecb4d1d", null ],
    [ "key", "d0/d8c/class_entitas_1_1_code_generator_1_1_index_key_attribute.html#a16802fa25115d70c19a8dc0f95d081f1", null ]
];