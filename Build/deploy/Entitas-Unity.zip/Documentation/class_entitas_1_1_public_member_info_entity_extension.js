var class_entitas_1_1_public_member_info_entity_extension =
[
    [ "CopyTo", "class_entitas_1_1_public_member_info_entity_extension.html#a41bb6fe71ac2306a92f7d4069386a38b", null ]
];