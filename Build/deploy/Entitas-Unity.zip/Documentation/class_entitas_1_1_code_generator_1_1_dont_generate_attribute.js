var class_entitas_1_1_code_generator_1_1_dont_generate_attribute =
[
    [ "DontGenerateAttribute", "class_entitas_1_1_code_generator_1_1_dont_generate_attribute.html#ad4a2598773ce3ff26e4e2cf5569fadec", null ],
    [ "generateIndex", "class_entitas_1_1_code_generator_1_1_dont_generate_attribute.html#a5d56b3fdce946814c4c264e1e288c523", null ]
];