var class_entitas_1_1_single_entity_exception =
[
    [ "SingleEntityException", "class_entitas_1_1_single_entity_exception.html#abb5f2b47f6f3963a3fd3611a016d1530", null ]
];