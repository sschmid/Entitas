var class_entitas_1_1_matcher_exception =
[
    [ "MatcherException", "class_entitas_1_1_matcher_exception.html#a5b04a297ad51a4f6201af4a41e69a26f", null ]
];