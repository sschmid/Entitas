var class_entitas_1_1_matcher_exception =
[
    [ "MatcherException", "class_entitas_1_1_matcher_exception.html#a2640c53044393c3923205875a92547ea", null ]
];