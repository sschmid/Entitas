var class_entitas_1_1_code_generator_1_1_pool_attribute =
[
    [ "PoolAttribute", "class_entitas_1_1_code_generator_1_1_pool_attribute.html#a80c72af565b7b0faca58a589bb731cd4", null ],
    [ "poolName", "class_entitas_1_1_code_generator_1_1_pool_attribute.html#a5e26c28f522b3f51ba123112d1688a19", null ]
];