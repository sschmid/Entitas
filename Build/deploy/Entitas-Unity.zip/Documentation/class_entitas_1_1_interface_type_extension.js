var class_entitas_1_1_interface_type_extension =
[
    [ "ImplementsInterface< T >", "class_entitas_1_1_interface_type_extension.html#a1e23f4d88940c01bb6e88e57fb422292", null ]
];