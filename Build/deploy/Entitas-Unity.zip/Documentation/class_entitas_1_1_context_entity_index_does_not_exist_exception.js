var class_entitas_1_1_context_entity_index_does_not_exist_exception =
[
    [ "ContextEntityIndexDoesNotExistException", "class_entitas_1_1_context_entity_index_does_not_exist_exception.html#a733cb123eae26bd04e217ab44140fdd3", null ]
];