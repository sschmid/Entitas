var class_entitas_1_1_context_entity_index_does_not_exist_exception =
[
    [ "ContextEntityIndexDoesNotExistException", "class_entitas_1_1_context_entity_index_does_not_exist_exception.html#a9f7fe851cdee7d18222d473954d0c0c4", null ]
];