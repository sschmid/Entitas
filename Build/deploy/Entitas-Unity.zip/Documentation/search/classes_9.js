var searchData=
[
  ['objectcache',['ObjectCache',['../class_entitas_1_1_object_cache.html',1,'Entitas']]],
  ['objectpool',['ObjectPool',['../class_entitas_1_1_object_pool.html',1,'Entitas']]]
];
