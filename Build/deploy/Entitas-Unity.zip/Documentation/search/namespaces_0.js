var searchData=
[
  ['entitas',['Entitas',['../namespace_entitas.html',1,'']]]
];
