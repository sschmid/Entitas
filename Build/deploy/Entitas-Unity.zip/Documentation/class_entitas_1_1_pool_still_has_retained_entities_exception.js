var class_entitas_1_1_pool_still_has_retained_entities_exception =
[
    [ "PoolStillHasRetainedEntitiesException", "class_entitas_1_1_pool_still_has_retained_entities_exception.html#a290a21bca62838ba460f5bf5e194d5ed", null ]
];