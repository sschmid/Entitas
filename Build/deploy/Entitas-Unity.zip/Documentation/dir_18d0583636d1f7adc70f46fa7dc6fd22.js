var dir_18d0583636d1f7adc70f46fa7dc6fd22 =
[
    [ "Caching", "dir_43bde035f3e8be84dceeb5ef79690128.html", "dir_43bde035f3e8be84dceeb5ef79690128" ],
    [ "CodeGenerator", "dir_869009037997bddb833873ae73502910.html", "dir_869009037997bddb833873ae73502910" ],
    [ "Extensions", "dir_1efbe5ff38eb8fbf4811d1cf1d3b68b8.html", "dir_1efbe5ff38eb8fbf4811d1cf1d3b68b8" ],
    [ "Interfaces", "dir_b4d3ecafd9849fd76c2839b0ca942f82.html", "dir_b4d3ecafd9849fd76c2839b0ca942f82" ],
    [ "Matcher", "dir_5b9febb0a1643b31f73c828c94068ca9.html", "dir_5b9febb0a1643b31f73c828c94068ca9" ],
    [ "Serialization", "dir_fdd12320f6892d1eccc9f299c7c26eb0.html", "dir_fdd12320f6892d1eccc9f299c7c26eb0" ],
    [ "EntitasException.cs", "_entitas_exception_8cs_source.html", null ],
    [ "Entity.cs", "_entity_8cs_source.html", null ],
    [ "EntityCollector.cs", "_entity_collector_8cs_source.html", null ],
    [ "EntityIndex.cs", "_entity_index_8cs_source.html", null ],
    [ "Group.cs", "_group_8cs_source.html", null ],
    [ "Pool.cs", "_pool_8cs_source.html", null ],
    [ "Pools.cs", "_pools_8cs_source.html", null ],
    [ "ReactiveSystem.cs", "_reactive_system_8cs_source.html", null ],
    [ "Systems.cs", "_systems_8cs_source.html", null ]
];