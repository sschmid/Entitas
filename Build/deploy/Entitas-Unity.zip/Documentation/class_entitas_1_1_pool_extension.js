var class_entitas_1_1_pool_extension =
[
    [ "CloneEntity", "class_entitas_1_1_pool_extension.html#a6287ecf826a5b986e25bcf99cb299785", null ],
    [ "CreateEntityCollector", "class_entitas_1_1_pool_extension.html#a411038149cdcc7212705235bbcb923ed", null ],
    [ "CreateSystem", "class_entitas_1_1_pool_extension.html#a2df9b33e82e2f2dfa17bc4935e28caf9", null ],
    [ "CreateSystem", "class_entitas_1_1_pool_extension.html#aca22dccf1e4d15a47ec986124c81e611", null ],
    [ "CreateSystem", "class_entitas_1_1_pool_extension.html#ac8e0aad0ba33afff39cb0fabcdd2e7eb", null ],
    [ "CreateSystem", "class_entitas_1_1_pool_extension.html#a6c7fd743065d37908cb533b7ee7ac9cd", null ],
    [ "CreateSystem", "class_entitas_1_1_pool_extension.html#a85b8f8a72467b53bfc611678c1882758", null ],
    [ "CreateSystem", "class_entitas_1_1_pool_extension.html#a71453c427d954144a2268831355ee344", null ],
    [ "CreateSystem", "class_entitas_1_1_pool_extension.html#a84cd1f29c1e4af36be47736e63af1e64", null ],
    [ "CreateSystem", "class_entitas_1_1_pool_extension.html#a8242df2e4511124575f4a3944465a9d0", null ],
    [ "CreateSystem", "class_entitas_1_1_pool_extension.html#a0cfa05864fc7dea080e778ac36273042", null ],
    [ "GetEntities", "class_entitas_1_1_pool_extension.html#a1b9f5507339a40dd56330be5e5ee078f", null ],
    [ "SetPool", "class_entitas_1_1_pool_extension.html#a83253055c4e915e9f2b304ff36cf45ab", null ],
    [ "SetPools", "class_entitas_1_1_pool_extension.html#a5ec9464089d7b86fab9d219e4d3754a6", null ]
];