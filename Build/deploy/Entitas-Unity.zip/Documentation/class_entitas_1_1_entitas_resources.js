var class_entitas_1_1_entitas_resources =
[
    [ "GetVersion", "class_entitas_1_1_entitas_resources.html#a24bdf0c5d30034e5f1dbc6b40ebdb7e1", null ]
];