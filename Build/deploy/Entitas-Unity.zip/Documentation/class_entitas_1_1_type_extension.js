var class_entitas_1_1_type_extension =
[
    [ "ImplementsInterface< T >", "class_entitas_1_1_type_extension.html#ad378941eb1727d00fd7774428dbd5883", null ]
];