var interface_entitas_1_1_i_a_e_r_c =
[
    [ "Release", "interface_entitas_1_1_i_a_e_r_c.html#ab43dc3fdaf04b76a019c8b472d559631", null ],
    [ "Retain", "interface_entitas_1_1_i_a_e_r_c.html#af9410b8c9cc6eef69b6451ee4579cd81", null ],
    [ "retainCount", "interface_entitas_1_1_i_a_e_r_c.html#afd673d4166abc7a34693cf1b3a48af7c", null ]
];