var class_entitas_1_1_type_serialization_extension =
[
    [ "RemoveDots", "class_entitas_1_1_type_serialization_extension.html#a941784ee558c714d482e7b81c0e6d219", null ],
    [ "ShortTypeName", "class_entitas_1_1_type_serialization_extension.html#a4e199998b07a9301c833556896a10e16", null ],
    [ "ToCompilableString", "class_entitas_1_1_type_serialization_extension.html#aa2b267c7fea7a9c29a624ca368ae7232", null ],
    [ "ToType", "class_entitas_1_1_type_serialization_extension.html#abd9d3a6e0ce638d4a90f368307ea204c", null ]
];