var class_entitas_1_1_type_serialization_extension =
[
    [ "ToCompilableString", "class_entitas_1_1_type_serialization_extension.html#aa2b267c7fea7a9c29a624ca368ae7232", null ],
    [ "ToType", "class_entitas_1_1_type_serialization_extension.html#abd9d3a6e0ce638d4a90f368307ea204c", null ]
];