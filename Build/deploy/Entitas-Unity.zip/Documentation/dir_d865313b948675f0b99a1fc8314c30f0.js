var dir_d865313b948675f0b99a1fc8314c30f0 =
[
    [ "Group.cs", "_group_8cs_source.html", null ],
    [ "GroupEvent.cs", "_group_event_8cs_source.html", null ],
    [ "GroupExtension.cs", "_group_extension_8cs_source.html", null ],
    [ "GroupSingleEntityException.cs", "_group_single_entity_exception_8cs_source.html", null ],
    [ "IGroup.cs", "_i_group_8cs_source.html", null ]
];