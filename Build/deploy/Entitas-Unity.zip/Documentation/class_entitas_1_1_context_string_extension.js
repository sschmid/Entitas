var class_entitas_1_1_context_string_extension =
[
    [ "AddContextSuffix", "class_entitas_1_1_context_string_extension.html#a2c947d9b7c84478eb4c6c495ee58d8b8", null ],
    [ "RemoveContextSuffix", "class_entitas_1_1_context_string_extension.html#a706077de1e72407bad52e9a93b6336da", null ]
];