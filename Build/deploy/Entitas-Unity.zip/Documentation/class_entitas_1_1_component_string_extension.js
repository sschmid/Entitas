var class_entitas_1_1_component_string_extension =
[
    [ "AddComponentSuffix", "class_entitas_1_1_component_string_extension.html#af3936a1147287200eec8331ba350b8a9", null ],
    [ "RemoveComponentSuffix", "class_entitas_1_1_component_string_extension.html#aa663bfdb34c6b0cd3968744a2894db4c", null ]
];