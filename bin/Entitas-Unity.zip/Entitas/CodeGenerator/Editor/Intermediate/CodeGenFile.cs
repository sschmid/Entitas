﻿namespace Entitas.CodeGenerator {
    public struct CodeGenFile {
        public string fileName;
        public string fileContent;
        public string generatorName;
    }
}

