﻿namespace Entitas {
    public interface ISystem {
    }
}

