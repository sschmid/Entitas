﻿namespace Entitas {
    public interface IInitializeSystem : ISystem {
        void Initialize();
    }
}

