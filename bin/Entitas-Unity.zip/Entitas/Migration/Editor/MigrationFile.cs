﻿namespace Entitas.Migration {
    public struct MigrationFile {
        public string fileName;
        public string fileContent;
    }
}

