﻿namespace Entitas.CodeGenerator {
    public interface ICodeGenerator {
    }
}

