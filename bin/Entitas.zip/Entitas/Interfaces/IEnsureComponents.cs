﻿namespace Entitas {
    public interface IEnsureComponents {
        IMatcher ensureComponents { get; }
    }
}

