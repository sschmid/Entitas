﻿namespace Entitas {
    public interface IClearReactiveSystem {
    }
}

