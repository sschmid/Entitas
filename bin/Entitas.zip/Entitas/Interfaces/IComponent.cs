﻿namespace Entitas {
    public interface IComponent {
    }
}

