﻿namespace Entitas {
    public interface IExecuteSystem : ISystem {
        void Execute();
    }
}

