﻿namespace Entitas {
    public interface IStartSystem : ISystem {
        void Start();
    }
}

