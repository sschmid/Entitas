﻿namespace Entitas {
    public interface IExcludeComponents {
        IMatcher excludeComponents { get; }
    }
}

