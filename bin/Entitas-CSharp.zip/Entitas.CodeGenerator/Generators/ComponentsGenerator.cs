﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Entitas.CodeGenerator {
    public class ComponentsGenerator : IComponentCodeGenerator {

        const string CLASS_SUFFIX = "GeneratedExtension";

        public CodeGenFile[] Generate(Type[] components) {
            return components
                    .Where(shouldGenerate)
                    .Aggregate(new List<CodeGenFile>(), (files, type) => {
                        files.Add(new CodeGenFile {
                            fileName = type + CLASS_SUFFIX,
                            fileContent = generateComponentExtension(type).ToUnixLineEndings()
                        });
                        return files;
                    }).ToArray();
        }

        static bool shouldGenerate(Type type) {
            return !Attribute.GetCustomAttributes(type)
                .Any(attr => attr is DontGenerateAttribute);
        }

        static string generateComponentExtension(Type type) {
            return type.PoolNames().Length == 0
                        ? addDefaultPoolCode(type)
                        : addCustomPoolCode(type);
        }

        static string addDefaultPoolCode(Type type) {
            var code = addNamespace();
            code += addEntityMethods(type);
            if (isSingleEntity(type)) {
                code += addPoolMethods(type);
            }
            code += addMatcher(type);
            code += closeNamespace();
            return code;
        }

        static string addCustomPoolCode(Type type) {
            var code = addUsings();
            code += addNamespace();
            code += addEntityMethods(type);
            if (isSingleEntity(type)) {
                code += addPoolMethods(type);
            }
            code += closeNamespace();
            code += addMatcher(type);
            return code;
        }

        static string addUsings() {
            return "using Entitas;\n\n";
        }

        static string addNamespace() {
            return @"namespace Entitas {";
        }

        static string closeNamespace() {
            return "}\n";
        }

        /*
         *
         * ENTITY METHODS
         *
         */

        static string addEntityMethods(Type type) {
            return addEntityClassHeader()
                    + addGetMethods(type)
                    + addHasMethods(type)
                    + addAddMethods(type)
                    + addReplaceMethods(type)
                    + addRemoveMethods(type)
                    + addCloseClass();
        }

        static string addEntityClassHeader() {
            return "\n    public partial class Entity {";
        }

        static string addGetMethods(Type type) {
            var getMethod = isSingletonComponent(type) ?
                "\n        static readonly $Type $nameComponent = new $Type();\n" :
                "\n        public $Type $name { get { return ($Type)GetComponent($Ids.$Name); } }\n";
            return buildString(type, getMethod);
        }

        static string addHasMethods(Type type) {
            var hasMethod = isSingletonComponent(type) ? @"
        public bool $prefix$Name {
            get { return HasComponent($Ids.$Name); }
            set {
                if (value != $prefix$Name) {
                    if (value) {
                        AddComponent($Ids.$Name, $nameComponent);
                    } else {
                        RemoveComponent($Ids.$Name);
                    }
                }
            }
        }

        public Entity $Prefix$Name(bool value) {
            $prefix$Name = value;
            return this;
        }
" : @"
        public bool has$Name { get { return HasComponent($Ids.$Name); } }
";
            return buildString(type, hasMethod);
        }

        static string addAddMethods(Type type) {
            return isSingletonComponent(type) ? string.Empty : buildString(type, @"
        public Entity Add$Name($typedArgs) {
            var componentPool = GetComponentPool($Ids.$Name);
            var component = ($Type)(componentPool.Count > 0 ? componentPool.Pop() : new $Type());
$assign
            return AddComponent($Ids.$Name, component);
        }
");
        }

        static string addReplaceMethods(Type type) {
            return isSingletonComponent(type) ? string.Empty : buildString(type, @"
        public Entity Replace$Name($typedArgs) {
            var componentPool = GetComponentPool($Ids.$Name);
            var component = ($Type)(componentPool.Count > 0 ? componentPool.Pop() : new $Type());
$assign
            ReplaceComponent($Ids.$Name, component);
            return this;
        }
");
        }

        static string addRemoveMethods(Type type) {
            return isSingletonComponent(type) ? string.Empty : buildString(type, @"
        public Entity Remove$Name() {
            return RemoveComponent($Ids.$Name);;
        }
");
        }

        /*
         *
         * POOL METHODS
         *
         */

        static string addPoolMethods(Type type) {
            return addPoolClassHeader(type)
                    + addPoolGetMethods(type)
                    + addPoolHasMethods(type)
                    + addPoolAddMethods(type)
                    + addPoolReplaceMethods(type)
                    + addPoolRemoveMethods(type)
                    + addCloseClass();
        }

        static string addPoolClassHeader(Type type) {
            return buildString(type, "\n    public partial class Pool {");
        }

        static string addPoolGetMethods(Type type) {
            var getMehod = isSingletonComponent(type) ? @"
        public Entity $nameEntity { get { return GetGroup($TagMatcher.$Name).GetSingleEntity(); } }
" : @"
        public Entity $nameEntity { get { return GetGroup($TagMatcher.$Name).GetSingleEntity(); } }

        public $Type $name { get { return $nameEntity.$name; } }
";
            return buildString(type, getMehod);
        }

        static string addPoolHasMethods(Type type) {
            var hasMethod = isSingletonComponent(type) ? @"
        public bool $prefix$Name {
            get { return $nameEntity != null; }
            set {
                var entity = $nameEntity;
                if (value != (entity != null)) {
                    if (value) {
                        CreateEntity().$prefix$Name = true;
                    } else {
                        DestroyEntity(entity);
                    }
                }
            }
        }
" : @"
        public bool has$Name { get { return $nameEntity != null; } }
";
            return buildString(type, hasMethod);
        }

        static object addPoolAddMethods(Type type) {
            return isSingletonComponent(type) ? string.Empty : buildString(type, @"
        public Entity Set$Name($typedArgs) {
            if (has$Name) {
                throw new EntitasException(""Could not set $name!\n"" + this + "" already has an entity with $Type!"",
                    ""You should check if the pool already has a $nameEntity before setting it or use pool.Replace$Name()."");
            }
            var entity = CreateEntity();
            entity.Add$Name($args);
            return entity;
        }
");
        }

        static string addPoolReplaceMethods(Type type) {
            return isSingletonComponent(type) ? string.Empty : buildString(type, @"
        public Entity Replace$Name($typedArgs) {
            var entity = $nameEntity;
            if (entity == null) {
                entity = Set$Name($args);
            } else {
                entity.Replace$Name($args);
            }

            return entity;
        }
");
        }

        static string addPoolRemoveMethods(Type type) {
            return isSingletonComponent(type) ? string.Empty : buildString(type, @"
        public void Remove$Name() {
            DestroyEntity($nameEntity);
        }
");
        }

        /*
        *
        * MATCHER
        *
        */

        static string addMatcher(Type type) {
            const string matcherFormat = @"
    public partial class $TagMatcher {
        static IMatcher _matcher$Name;

        public static IMatcher $Name {
            get {
                if (_matcher$Name == null) {
                    var matcher = (Matcher)Matcher.AllOf($Ids.$Name);
                    matcher.componentNames = $Ids.componentNames;
                    _matcher$Name = matcher;
                }

                return _matcher$Name;
            }
        }
    }
";
            var poolNames = type.PoolNames();
            if (poolNames.Length == 0) {
                return buildString(type, matcherFormat);
            }

            var matchers = poolNames.Aggregate(string.Empty, (acc, poolName) => {
                return acc + buildString(type, matcherFormat.Replace("$Tag", poolName));
            });

            return buildString(type, matchers);
        }

        /*
         *
         * HELPERS
         *
         */

        static bool isSingleEntity(Type type) {
            return Attribute.GetCustomAttributes(type)
                .Any(attr => attr is SingleEntityAttribute);
        }

        static bool isSingletonComponent(Type type) {
            var bindingFlags = BindingFlags.Instance | BindingFlags.Public;
            return type.GetFields(bindingFlags).Length == 0;
        }

        static string buildString(Type type, string format) {
            format = createFormatString(format);
            var a0_type = type;
            var a1_name = type.RemoveComponentSuffix();
            var a2_lowercaseName = a1_name.LowercaseFirst();
            var poolNames = type.PoolNames();
            var a3_tag = poolNames.Length == 0 ? string.Empty : poolNames[0];
            var lookupTags = type.ComponentLookupTags();
            var a4_ids = lookupTags.Length == 0 ? string.Empty : lookupTags[0];
            var memberNameInfos = getFieldInfos(type);
            var a5_fieldNamesWithType = fieldNamesWithType(memberNameInfos);
            var a6_fieldAssigns = fieldAssignments(memberNameInfos);
            var a7_fieldNames = fieldNames(memberNameInfos);
            var prefix = type.CustomPrefix();
            var a8_prefix = prefix.UppercaseFirst();
            var a9_lowercasePrefix = prefix.LowercaseFirst();

            return string.Format(format, a0_type, a1_name, a2_lowercaseName,
                a3_tag, a4_ids, a5_fieldNamesWithType, a6_fieldAssigns, a7_fieldNames,
                a8_prefix, a9_lowercasePrefix);
        }

        static MemberTypeNameInfo[] getFieldInfos(Type type) {
            return type.GetFields(BindingFlags.Instance | BindingFlags.Public)
                .Select(field => new MemberTypeNameInfo { name = field.Name, type = field.FieldType })
                .ToArray();
        }

        static string createFormatString(string format) {
            return format.Replace("{", "{{")
                        .Replace("}", "}}")
                        .Replace("$Type", "{0}")
                        .Replace("$Name", "{1}")
                        .Replace("$name", "{2}")
                        .Replace("$Tag", "{3}")
                        .Replace("$Ids", "{4}")
                        .Replace("$typedArgs", "{5}")
                        .Replace("$assign", "{6}")
                        .Replace("$args", "{7}")
                        .Replace("$Prefix", "{8}")
                        .Replace("$prefix", "{9}");
        }

        static string fieldNamesWithType(MemberTypeNameInfo[] infos) {
            var typedArgs = infos.Select(info => {
                var newArg = "new" + info.name.UppercaseFirst();
                var typeString = TypeGenerator.Generate(info.type);
                return typeString + " " + newArg;
            }).ToArray();

            return string.Join(", ", typedArgs);
        }

        static string fieldAssignments(MemberTypeNameInfo[] infos) {
            const string format = "            component.{0} = {1};";
            var assignments = infos.Select(info => {
                var newArg = "new" + info.name.UppercaseFirst();
                return string.Format(format, info.name, newArg);
            }).ToArray();

            return string.Join("\n", assignments);
        }

        static string fieldNames(MemberTypeNameInfo[] infos) {
            var args = infos.Select(info => "new" + info.name.UppercaseFirst()).ToArray();
            return string.Join(", ", args);
        }

        static string addCloseClass() {
            return "    }\n";
        }
    }

    struct MemberTypeNameInfo {
        public string name;
        public Type type;
    }
}

